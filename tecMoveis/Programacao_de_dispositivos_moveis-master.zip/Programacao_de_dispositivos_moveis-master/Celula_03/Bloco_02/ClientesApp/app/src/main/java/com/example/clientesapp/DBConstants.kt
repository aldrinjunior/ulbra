package com.example.clientesapp

val DATABASE_NAME = "clientes.db"
val DATABASE_VERSION = 2
val TABLE_CLIENTES = "CLIENTE"
val CLIENTE_ID = "ID"
val CLIENTE_NOME = "NOME"
val CLIENTE_FONE = "FONE"
val CLIENTE_IDADE = "IDADE"
