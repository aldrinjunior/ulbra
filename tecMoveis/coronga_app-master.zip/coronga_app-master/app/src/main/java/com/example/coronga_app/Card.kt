package com.example.coronga_app

class Card(
    val titulo: String,
    val mortos: Int,
    val suspeitos: Int,
    val recusados: Int,
    val uf: String?
);