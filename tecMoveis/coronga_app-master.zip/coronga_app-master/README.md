# Coronga APP

Aplicativo desenvolvido para a disciplina de Tecnologias Móveis na Ulbra

Dupla com @olivermathe

Este aplicativo tem a finalidade de mostrar todos os casos de infectados, curados, e mortos em todos os países, e também os estados do Brasil 

Dados da api :  https://covid19-brazil-api.now.sh/api/report/v1


## Installation

Abra o projeto no android studio e espere ele baixar todas as dependências necessárias 


## License
[MIT](https://choosealicense.com/licenses/mit/)
